package fr.mjtchoupe.deezer.service.dataClasses

data class Data(
    val id: Int,
    val name: String,
    val picture: String,
    val type: String
)