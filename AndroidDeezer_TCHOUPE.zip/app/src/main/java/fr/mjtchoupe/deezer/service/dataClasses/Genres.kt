package fr.mjtchoupe.deezer.service.dataClasses

data class Genres(
    val `data`: List<Data>
)