package fr.mjtchoupe.deezer.service.dataClasses

data class ArtistXX(
    val id: Int,
    val name: String,
    val tracklist: String,
    val type: String
)