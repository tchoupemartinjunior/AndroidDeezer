package fr.mjtchoupe.deezer.service.dataClasses

data class Tracks(
    val `data`: List<DataX>
)